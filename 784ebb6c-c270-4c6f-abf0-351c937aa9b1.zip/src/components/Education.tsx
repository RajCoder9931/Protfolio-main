import React from 'react';
const Education = () => {
  const education = [{
    id: 1,
    degree: 'Master of Science in Computer Science',
    institution: 'Stanford University',
    duration: '2014 - 2016',
    description: 'Specialized in Artificial Intelligence and Machine Learning. Graduated with honors.',
    achievements: ['Research Assistant', "Dean's List", 'Published paper on neural networks']
  }, {
    id: 2,
    degree: 'Bachelor of Science in Software Engineering',
    institution: 'Massachusetts Institute of Technology',
    duration: '2010 - 2014',
    description: 'Focused on software development methodologies and computer systems.',
    achievements: ['Cum Laude', 'Student Council President', 'Hackathon Winner']
  }];
  return <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-2">Education</h2>
          <div className="w-24 h-1 bg-indigo-600 mx-auto"></div>
        </div>
        <div className="max-w-4xl mx-auto">
          {education.map(edu => <div key={edu.id} className="bg-slate-50 rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow mb-8">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                <h3 className="text-xl font-bold">{edu.degree}</h3>
                <p className="text-indigo-600 font-medium">{edu.duration}</p>
              </div>
              <p className="text-lg mb-3">{edu.institution}</p>
              <p className="text-slate-600 mb-4">{edu.description}</p>
              <div>
                <h4 className="font-semibold mb-2">Achievements:</h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600">
                  {edu.achievements.map((achievement, index) => <li key={index}>{achievement}</li>)}
                </ul>
              </div>
            </div>)}
        </div>
      </div>
    </section>;
};
export default Education;