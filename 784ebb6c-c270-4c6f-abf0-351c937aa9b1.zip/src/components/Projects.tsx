import React, { useState } from 'react';
import ProjectCard from './ProjectCard';
const Projects = () => {
  const [filter, setFilter] = useState('all');
  const projects = [{
    id: 1,
    title: 'E-Commerce Platform',
    description: 'A full-featured online store with product listings, cart functionality, and payment integration.',
    image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80',
    technologies: ['React', 'Node.js', 'MongoDB', 'Stripe'],
    category: 'fullstack',
    demoUrl: 'https://example.com',
    githubUrl: 'https://github.com/example'
  }, {
    id: 2,
    title: 'Task Management App',
    description: 'A Trello-inspired task management application with drag-and-drop functionality.',
    image: 'https://images.unsplash.com/photo-1540350394557-8d14678e7f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1332&q=80',
    technologies: ['React', 'TypeScript', 'Firebase'],
    category: 'frontend',
    demoUrl: 'https://example.com',
    githubUrl: 'https://github.com/example'
  }, {
    id: 3,
    title: 'Real-time Chat Application',
    description: 'A chat application with real-time messaging, user authentication, and notification features.',
    image: 'https://images.unsplash.com/photo-1611746869696-d09bce200020?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80',
    technologies: ['React', 'Socket.io', 'Express', 'MongoDB'],
    category: 'fullstack',
    demoUrl: 'https://example.com',
    githubUrl: 'https://github.com/example'
  }, {
    id: 4,
    title: 'Weather Dashboard',
    description: 'A weather application that displays current and forecasted weather data from multiple sources.',
    image: 'https://images.unsplash.com/photo-1592210454359-9043f067919b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80',
    technologies: ['JavaScript', 'OpenWeatherMap API', 'HTML5', 'CSS3'],
    category: 'frontend',
    demoUrl: 'https://example.com',
    githubUrl: 'https://github.com/example'
  }, {
    id: 5,
    title: 'Content Management System',
    description: 'A custom CMS built for content creators with markdown support and SEO optimization.',
    image: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80',
    technologies: ['Next.js', 'GraphQL', 'PostgreSQL'],
    category: 'fullstack',
    demoUrl: 'https://example.com',
    githubUrl: 'https://github.com/example'
  }, {
    id: 6,
    title: 'API Gateway Service',
    description: 'A microservice that handles API routing, rate limiting, and authentication for a larger system.',
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1034&q=80',
    technologies: ['Node.js', 'Express', 'Redis', 'Docker'],
    category: 'backend',
    demoUrl: 'https://example.com',
    githubUrl: 'https://github.com/example'
  }];
  const filteredProjects = filter === 'all' ? projects : projects.filter(project => project.category === filter);
  return <section id="projects" className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-2">My Projects</h2>
          <div className="w-24 h-1 bg-indigo-600 mx-auto"></div>
        </div>
        <div className="flex justify-center mb-8">
          <div className="inline-flex flex-wrap justify-center gap-2">
            {['all', 'frontend', 'backend', 'fullstack'].map(category => <button key={category} onClick={() => setFilter(category)} className={`px-4 py-2 rounded-full text-sm ${filter === category ? 'bg-indigo-600 text-white' : 'bg-white text-slate-600 hover:bg-slate-100'} transition-colors`}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>)}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map(project => <ProjectCard key={project.id} title={project.title} description={project.description} image={project.image} technologies={project.technologies} demoUrl={project.demoUrl} githubUrl={project.githubUrl} />)}
        </div>
      </div>
    </section>;
};
export default Projects;